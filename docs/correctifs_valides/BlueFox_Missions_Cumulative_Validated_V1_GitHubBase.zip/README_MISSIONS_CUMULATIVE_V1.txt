BLUEFOX ODYSSEY — CORRECTIF CUMULATIF MISSIONS V1

BASE
À appliquer sur une copie propre du dépôt GitHub SattaSam/N-1, branche main,
tel qu'audité au moment de génération de ce correctif.

LE DÉPÔT CONTIENT DÉJÀ
- BibleRuntime V0 + 3 missions test.
- patrons et catalogue V0.
- persistance F5 des missions.
- fan-out passif multi-missions.
- empty-core non destructif.

CE ZIP AJOUTE UNIQUEMENT LES ÉTAPES VALIDÉES ENSUITE
1. Arbitrage autonome entre mission principale et missions secondaires.
   - principale poids 100 ;
   - budget global secondaires 20 ;
   - max 3 propositions secondaires ;
   - pondération finale par le BAC.
2. Une action secondaire garde son missionId et se termine dans son propre arbre.
3. Une interaction objet refusée renvoie false au moteur de mission.
4. Nettoyage des marqueurs d'interaction refusée.
5. Reset de cible de déplacement résiduelle après refus.
6. Watchdog : currentAction orpheline >5 s + moteur idle => annulation/replanification.

NON INCLUS
- problème hitbox du cactus ;
- BUILD/CRAFT autonome ;
- nouveaux patrons ou nouvelles missions Bible.

INSTALLATION
1. Partir d'une copie propre du main GitHub actuel.
2. Extraire ce ZIP à la racine.
3. Lancer INSTALLER_MISSIONS_CUMULATIVE_V1.bat.
4. Le script fait un précheck complet avant toute écriture.
5. Des backups .bak sont créés.

TEST RAPIDE
- Nouvelle partie.
- Lancer :
  BlueFox3D.startBibleMission("BIBLE-V0-DISCOVERY")
  BlueFox3D.startBibleMission("BIBLE-V0-ARCHAEOLOGY")
- Mettre ARCHAEOLOGY en priorité.
- Laisser BlueFox autonome.
ATTENDU :
- secondaire peut progresser sans devenir prioritaire ;
- principale reste dominante ;
- aucune currentAction ne doit bloquer indéfiniment ;
- F5 conserve l'état.
